// +build ignore

package main

import "."

func main() {
	easysub.Hello()
}
